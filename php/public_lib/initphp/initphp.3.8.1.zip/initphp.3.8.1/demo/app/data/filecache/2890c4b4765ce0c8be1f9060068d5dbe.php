<?php exit;?>1353987991(5)s:694:"前置Action，会在正常Action运行前执行<br/><br/>Hello World<br/><br/><a href='index.php?c=index&a=test'>跳转到test这个Action!</a><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<form action="http://127.0.0.1:88" method="post">
<input name="username" type="text" />
<input name="age" type="text" />
<input name="" type="submit" />
</form>
</body>
</html>
<br/><br/>后置Action，会在正常Action运行后运行<br/><br/>";