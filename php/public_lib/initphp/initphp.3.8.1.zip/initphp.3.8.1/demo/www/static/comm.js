// JavaScript Document
$(document).ready(function () {
$("pre").addClass("prettyprint");
prettyPrint();
}); 